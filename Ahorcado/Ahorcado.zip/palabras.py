import random

palabras = [
    'abecedario', 'barco', 'caballo', 'dinosaurio', 'elefante', 'fresa', 'guitarra', 'hamburguesa', 'iglesia', 'jirafa',
    'koala', 'limón', 'manzana', 'naranja', 'oso', 'piano', 'queso', 'ratón', 'sandía', 'tortuga', 'uva', 'vaca', 'zanahoria',
    'abeja', 'ballena', 'cabra', 'delfín', 'escuela', 'flor', 'gato', 'helado', 'isla', 'juego', 'kiwi', 'león', 'mariposa',
    'nube', 'ojo', 'pájaro', 'quesadilla', 'rana', 'serpiente', 'tigre', 'unicornio', 'volcán', 'xilófono', 'yate', 'zorro',
    'anillo', 'bolígrafo', 'calcetín', 'dado', 'escoba', 'fuego', 'globo', 'hilo', 'imán', 'joya', 'kilogramo', 'linterna',
    'martillo', 'nuez', 'ostra', 'pluma', 'quiosco', 'reloj', 'sombrero', 'taza', 'uña', 'vela', 'waffle', 'yogur', 'zapato',
    'árbol', 'buho', 'campana', 'dados', 'estrella', 'faro', 'guitarra', 'hacha', 'iguana', 'jirafa', 'koala', 'lagarto',
    'manzana', 'nariz', 'oruga', 'pelota', 'queso', 'rana', 'serpiente', 'tigre', 'uña', 'vaca', 'zanahoria', 'ángel', 'bola',
    'cama', 'dado', 'elefante', 'flor', 'gato', 'helado', 'iglesia', 'jungla', 'kiosco', 'luna', 'manzana', 'nido', 'ojo',
    'pelota', 'queso', 'ratón', 'sol', 'taza', 'uva', 'ventana', 'yogur', 'zapato'
]



